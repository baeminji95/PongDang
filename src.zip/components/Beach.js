export function seedData() {
        const BEACHS = [
        {
                num: 1, region: "인천", name: "을왕리 해수욕장",
                nx: 49, ny: 124, lat: 37.44630, lng: 126.37273
        },
        {
                num: 2, region: "인천", name: "왕산 해수욕장",
                nx: 49, ny: 124, lat: 37.45570, lng: 126.36970
        },
        {
                num: 3, region: "인천", name: "하나개 해수욕장",
                nx: 50, ny: 123, lat: 37.38484, lng: 126.40985
        },
        // { num:4, region:"인천", name:"사계해안", nx:49, ny:32 },
        // { num:5, region:"인천", name:"하모해변", nx:48, ny:32 },
        // { num:6, region:"인천", name:"민머루 해수욕장", nx:49, ny:128 },
        // { num:7, region:"인천", name:"장경리 해수욕장", nx:51, ny:120 },
        {
                num: 29, region: "제주", name: "월정리해변",
                nx: 58, ny: 39, lat: 33.55650, lng: 126.79580
        },
        {
                num: 250, region: "강원", name: "죽도 해수욕장",
                nx: 90, ny: 136, lat: 37.97295, lng: 128.76072
        },
        {
                num: 252, region: "강원", name: "인구 해수욕장",
                nx: 90, ny: 136, lat: 37.96911, lng: 128.76253
        },
        {
                num: 305, region: "부산", name: "송정 해수욕장",
                nx: 100, ny: 76, lat: 35.17860, lng: 129.19970
        },
        {
                num: 308, region: "부산", name: "다대포 해수욕장",
                nx: 96, ny: 73, lat: 35.04654, lng: 128.96274
        },
        {
                num: 347, region: "제주", name: "중문 해수욕장",
                nx: 51, ny: 32, lat: 33.24506, lng: 126.41150
        },
];saveToBeachs(BEACHS);
// localStorage.setItem("seedBeachs", JSON.stringify(BEACHS));
};

function saveToBeachs(seedBeachs) {
localStorage.setItem("seedBeachs", JSON.stringify(seedBeachs));
}

// 앱 첫 사용인 경우 샘플데이터 생성
if (!localStorage.getItem("seedBeachs")) {
seedData();
}
