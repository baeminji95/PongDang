// import { useState } from "react";
// import { BEACHS } from "./Beach";
// import { Map, MapMarker } from "react-kakao-maps-sdk";
// import {
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
// } from 'recharts';
// import { YYYYMMDD } from "../App";
// import { hh } from "../App";


// export default function SearchBar() {

//   const [selectLocal, setSelectLocal] = useState([]);
//   const [beachNum, setBeachNum] = useState();
//   const [beachName, setBeachName] = useState();
//   const [nx, setNx] = useState(null);
//   const [ny, setNy] = useState(null);
//   const [lat, setLat] = useState();
//   const [lng, setLng] = useState();

//   const locals = [
//     { value: "InCheon", name: "인천", beaches: BEACHS.filter(beach => beach.region === "인천") },
//     { value: "YangYang", name: "양양", beaches: BEACHS.filter(beach => beach.region === "양양") },
//     { value: "JeJu", name: "제주", beaches: BEACHS.filter(beach => beach.region === "제주") },
//     { value: "PuSan", name: "부산", beaches: BEACHS.filter(beach => beach.region === "부산") },
//   ]

//   function handelLocalSelect(e) {
//     setSelectLocal(locals.find(select => select.value === e.target.value).beaches);
//   }

//   function handelBeachSelect(e) {
//     setBeachNum(e.target.value)
//     setNx(BEACHS.find(beach => beach.num.toString() === e.target.value).nx)
//     setNy(BEACHS.find(beach => beach.num.toString() === e.target.value).ny)
//   }



//   const [wh, setWh] = useState();
//   const [forecast, setForecasth] = useState();
//   const [wt, setWt] = useState();
//   const [temperatures, setTemperatures] = useState();

//   const [vilageFcst, setVilageFcst] = useState();
//   const [alldayWt, setAlldayWt] = useState();
//   const [alldayWh, setAlldayWh] = useState();

//   const [chartInfo, setChartInfo] = useState([]);

//   console.log(alldayWh)
//   //키 스테이트 추적
//   // console.log(wh)
//   // console.log(forecast)
//   // console.log(wt)
//   // console.log(vilageFcst)

//   if (alldayWt && vilageFcst&& alldayWh && chartInfo.length === 0) {
//     setChartInfo([
//       {
//         name: '03:00',
//         수온: (alldayWt[0] ? Number(alldayWt[0].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[0] ? Number(alldayWh[0].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[0].fcstValue)
//       },
//       {
//         name: '06:00',
//         수온: (alldayWt[1] ? Number(alldayWt[1].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[1] ? Number(alldayWh[1].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[36].fcstValue)
//       },
//       {
//         name: '09:00',
//         수온: (alldayWt[2] ? Number(alldayWt[2].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[2] ? Number(alldayWh[2].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[73].fcstValue)
//       },
//       {
//         name: '12:00',
//         수온: (alldayWt[3] ? Number(alldayWt[3].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[3] ? Number(alldayWh[3].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[109].fcstValue)
//       },
//       {
//         name: '15:00',
//         수온: (alldayWt[4] ? Number(alldayWt[4].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[4] ? Number(alldayWh[4].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[145].fcstValue)
//       },
//       {
//         name: '18:00',
//         수온: (alldayWt[5] ? Number(alldayWt[5].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[5] ? Number(alldayWh[5].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[182].fcstValue)
//       },
//       {
//         name: '21:00',
//         수온: (alldayWt[6] ? Number(alldayWt[6].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[6] ? Number(alldayWh[6].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[218].fcstValue)
//       },
//       {
//         name: '24:00',
//         수온: (alldayWt[7] ? Number(alldayWt[7].response.body.items.item[0].tw) : null),
//         파고: (alldayWh[7] ? Number(alldayWh[7].response.body.items.item[0].wh) : null),
//         기온: Number(vilageFcst.response.body.items.item[254].fcstValue)
//       },
//     ])
//   }

//   async function getInfo(e) {
//     e.preventDefault();

//     //지도용 변수
//     setBeachName(BEACHS.find(beach => beach.num.toString() === beachNum).name)
//     setLat(BEACHS.find(beach => beach.num.toString() === beachNum).lat)
//     setLng(BEACHS.find(beach => beach.num.toString() === beachNum).lng)

//     //파고
//     function whUrl(hh){
//       let whUrl = "http://apis.data.go.kr/1360000/BeachInfoservice/getWhBuoyBeach";
//       // query
//       whUrl += `?serviceKey=` + process.env.REACT_APP_API_KEY
//       whUrl += "&numOfRows=10"
//       whUrl += "&pageNo=1"
//       whUrl += "&dataType=JSON"
//       whUrl += `&beach_num=${beachNum}`
//       whUrl += `&searchTime=${YYYYMMDD}${hh}00`
//       return(whUrl)
//     }

//     //초단기
//     let forecastUrl = "http://apis.data.go.kr/1360000/BeachInfoservice/getUltraSrtFcstBeach";
//     //query
//     forecastUrl += `?serviceKey=` + process.env.REACT_APP_API_KEY
//     forecastUrl += "&numOfRows=10"
//     forecastUrl += "&pageNo=1"
//     forecastUrl += "&dataType=JSON"
//     forecastUrl += `&base_date=${YYYYMMDD}`
//     forecastUrl += `&base_time=${hh}00`
//     forecastUrl += `&beach_num=${beachNum}`

//     //수온
//     function wtUrl(hh) {
//       let wtUrl = "http://apis.data.go.kr/1360000/BeachInfoservice/getTwBuoyBeach"
//       //query
//       wtUrl += `?serviceKey=` + process.env.REACT_APP_API_KEY
//       wtUrl += "&numOfRows=1"
//       wtUrl += "&pageNo=10"
//       wtUrl += "&dataType=JSON"
//       wtUrl += `&beach_num=${beachNum}`
//       wtUrl += `&searchTime=${YYYYMMDD}${hh}00`
//       return(wtUrl)
//     }

//     //기온 /동네예보 초단기 실황
//     let temperaturesUrl = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst";
//     //query
//     temperaturesUrl += `?serviceKey=` + process.env.REACT_APP_API_KEY
//     temperaturesUrl += "&pageNo=1";
//     temperaturesUrl += "&numOfRows=1000";
//     temperaturesUrl += "&dataType=JSON";
//     temperaturesUrl += `&base_date=${YYYYMMDD}`
//     temperaturesUrl += `&base_time=${hh}00`
//     temperaturesUrl += `&nx=${nx}`;
//     temperaturesUrl += `&ny=${ny}`;

//     //기온 /동네예보 단기 예보
//     let vilageFcstUrl = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst";
//     //query
//     vilageFcstUrl += `?serviceKey=` + process.env.REACT_APP_API_KEY
//     vilageFcstUrl += "&pageNo=1";
//     vilageFcstUrl += "&numOfRows=1000";
//     vilageFcstUrl += "&dataType=JSON";
//     vilageFcstUrl += `&base_date=${YYYYMMDD}`
//     vilageFcstUrl += `&base_time=0200`
//     vilageFcstUrl += `&nx=${nx}`;
//     vilageFcstUrl += `&ny=${ny}`;


//     try {
//       const res1 = await fetch(whUrl(hh), {});
//       const res2 = await fetch(forecastUrl, {});
//       const res3 = await fetch(wtUrl(hh), {});
//       const res4 = await fetch(temperaturesUrl, {});
//       const res5 = await fetch(vilageFcstUrl, {});

//       setWh(await res1.json());
//       setForecasth(await res2.json());
//       setWt(await res3.json());
//       setTemperatures(await res4.json());
//       setVilageFcst(await res5.json());

//       //차트용
//       if (hh < 3) {
//         const resA = await fetch(wtUrl("00"), {});

//         const res1 = await fetch(whUrl("00"), {});

//         setAlldayWt([await resA.json()])
//         setAlldayWh([await res1.json()])
      
//       } else if (hh < 6) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});

//         setAlldayWt([await resA.json(), await resB.json()])
//         setAlldayWh([await res1.json(), await res2.json()])
      
//       } else if (hh < 9) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json()])
      
//       } else if (hh < 12) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});
//         const resD = await fetch(wtUrl("09"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});
//         const res4 = await fetch(whUrl("09"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json(), await resD.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json(), await res4.json()])

//       } else if (hh < 15) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});
//         const resD = await fetch(wtUrl("09"), {});
//         const resE = await fetch(wtUrl("12"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});
//         const res4 = await fetch(whUrl("09"), {});
//         const res5 = await fetch(whUrl("12"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json(), await resD.json(), await resE.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json(), await res4.json(), await res5.json()])

//       } else if (hh < 18) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});
//         const resD = await fetch(wtUrl("09"), {});
//         const resE = await fetch(wtUrl("12"), {});
//         const resF = await fetch(wtUrl("15"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});
//         const res4 = await fetch(whUrl("09"), {});
//         const res5 = await fetch(whUrl("12"), {});
//         const res6 = await fetch(whUrl("15"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json(), await resD.json(), await resE.json(), await resF.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json(), await res4.json(), await res5.json(), await res6.json()])

//       } else if (hh < 21) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});
//         const resD = await fetch(wtUrl("09"), {});
//         const resE = await fetch(wtUrl("12"), {});
//         const resF = await fetch(wtUrl("15"), {});
//         const resG = await fetch(wtUrl("18"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});
//         const res4 = await fetch(whUrl("09"), {});
//         const res5 = await fetch(whUrl("12"), {});
//         const res6 = await fetch(whUrl("15"), {});
//         const res7 = await fetch(whUrl("18"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json(), await resD.json(), await resE.json(), await resF.json(), await resG.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json(), await res4.json(), await res5.json(), await res6.json(), await res7.json()])

//       } else if (hh <= 24) {
//         const resA = await fetch(wtUrl("00"), {});
//         const resB = await fetch(wtUrl("03"), {});
//         const resC = await fetch(wtUrl("06"), {});
//         const resD = await fetch(wtUrl("09"), {});
//         const resE = await fetch(wtUrl("12"), {});
//         const resF = await fetch(wtUrl("15"), {});
//         const resG = await fetch(wtUrl("18"), {});
//         const resH = await fetch(wtUrl("21"), {});

//         const res1 = await fetch(whUrl("00"), {});
//         const res2 = await fetch(whUrl("03"), {});
//         const res3 = await fetch(whUrl("06"), {});
//         const res4 = await fetch(whUrl("09"), {});
//         const res5 = await fetch(whUrl("12"), {});
//         const res6 = await fetch(whUrl("15"), {});
//         const res7 = await fetch(whUrl("18"), {});
//         const res8 = await fetch(whUrl("21"), {});

//         setAlldayWt([await resA.json(), await resB.json(), await resC.json(), await resD.json(), await resE.json(), await resF.json(), await resG.json(), await resH.json()])
//         setAlldayWh([await res1.json(), await res2.json(), await res3.json(), await res4.json(), await res5.json(), await res6.json(), await res7.json(), await res8.json()])
//       }

//       //차트데이터 초기화
//       setChartInfo([])

//     } catch (error) {
//       throw new Error(error)
//     }
//   }

//   return (
//     <>
//       <form className="w-[90%] max-w-[40rem] mx-auto flex justify-between items-center border border-white rounded-full bg-blue-950/30 gap-5 px-4 py-3 hover:bg-blue-950/50">
//         <div className="flex">
//           <select
//             className="w-[4.5rem] font-bold text-[1.3rem] text-white bg-inherit  shadow-none"
//             onChange={handelLocalSelect}
//           >
//             <option className="text-[#000]">지역</option>
//             {locals.map((local) => (
//               <option
//                 className="text-[#000]"
//                 key={local.value}
//                 value={local.value}
//               >
//                 {local.name}
//               </option>
//             ))}
//           </select>
//           <div className="w-[1px] mx-3 bg-white"></div>
//           <select
//             className="w-[15rem] font-bold text-[1.3rem] text-white bg-inherit"
//             onChange={handelBeachSelect}
//           >
//             <option className="text-[#000]">어느 해변으로 갈까요?</option>
//             {selectLocal.map((beach) => (
//               <option
//                 className="text-[#000]"
//                 key={beach.num}
//                 value={beach.num}
//               >
//                 {beach.name}
//               </option>
//             ))}
//           </select>
//         </div>
//         <button type="submit" onClick={getInfo}>
//           <svg
//             className="w-5 fill-white"
//             xmlns="http://www.w3.org/2000/svg"
//             viewBox="0 0 512 512"
//           >
//             <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
//           </svg>
//         </button>
//       </form>

//       {wh && wt && forecast && temperatures && (
//         <div
//           className="w-[90%] mx-auto my-5 border rounded-[3rem] bg-blue-950/30 px-8 py-4 pb-8  
//           "
//         >
//           <p className="border-b font-semibold pl-4 my-3 text-white text-[1.8rem]">
//             {beachName}

            
//           </p>

//           <div className="w-[100%] flex justify-center">

//             <div className="w-[100%] grow">
//               <Map
//                 className="h-[15rem] lg:h-[20rem] border-4"
//                 center={{ lat: lat, lng: lng }}
//               >
//                 <MapMarker position={{ lat: lat, lng: lng }}>
//                   <div className=" font-semibold">
//                     {beachName}
//                   </div>
//                 </MapMarker>
//               </Map>
//             </div>

//             <div className="w-[10rem] flex flex-col justify-between mt-3 ml-5">
//               {forecast.response.body.items.item[8].fcstValue === "0"
//                 ? <p className="text-[4.5rem] relative">☀<span className="absolute top-2 left-0 text-white text-[1rem] font-bold drop-shadow-md">맑음</span></p>
//                 : <p className="text-[4.5rem] relative">🌧<span className="absolute top-2 left-0 text-white text-[1rem] font-bold">비</span></p>}


//               <p className=" text-white font-semibold">
//                 기온: {temperatures.response.body.items.item[3].obsrValue}℃
//               </p>

//               <p className="text-white font-semibold">
//                 풍속: {temperatures.response.body.items.item[7].obsrValue}m/s
//               </p>

//               <p className=" text-white font-semibold">
//                 파고: {wh.response.body.items.item[0].wh}m
//               </p>

//               <p className=" text-white font-semibold">
//                 수온: {wt.response.body.items.item[0].tw}℃
//               </p>
//             </div>
//           </div>
//           <div>
//             {/* 수온 */}
//             <ResponsiveContainer width="95%" height={300} className="bg-blue-950/30 mx-auto mt-10">
//               <LineChart
//                 width={500}
//                 height={300}
//                 data={chartInfo}
//                 margin={{
//                   top: 20,
//                   right: 40,
//                 }}
//               >
//                 <CartesianGrid strokeDasharray="3 3" />
//                 <XAxis dataKey="name" stroke="#0df" />
//                 <YAxis type="number" stroke="#0df"  domain={['dataMin-0.1', 'dataMax+0.1']} />
//                 <Tooltip />
//                 <Legend />
//                 <Line type="monotone" dataKey="수온" stroke="#0df" />
                
//               </LineChart>
//             </ResponsiveContainer>
// {/* 기온 */}
//             <ResponsiveContainer width="95%" height={300} className="bg-blue-950/30 mx-auto mt-10">
//               <LineChart
//                 width={500}
//                 height={300}
//                 data={chartInfo}
//                 margin={{
//                   top: 20,
//                   right: 40,
//                 }}
//               >
//                 <CartesianGrid strokeDasharray="3 3" />
//                 <XAxis dataKey="name" stroke="#1e1"/>
//                 <YAxis type="number" stroke="#1e1" domain={['dataMin-1', 'dataMax+1']} tickCount={6} />
//                 <Tooltip />
//                 <Legend />
//                 <Line type="monotone" dataKey="기온" stroke="#1e1" />
//               </LineChart>
//             </ResponsiveContainer>
// {/* 파고 */}
//             <ResponsiveContainer width="95%" height={300} className="bg-blue-950/30 mx-auto mt-10">
//               <LineChart
//                 width={500}
//                 height={300}
//                 data={chartInfo}
//                 margin={{
//                   top: 20,
//                   right: 40,
//                 }}
//               >
//                 <CartesianGrid strokeDasharray="3 3" />
//                 <XAxis dataKey="name" stroke="#0da"/>
//                 <YAxis type="number" stroke="#0da" domain={['dataMin - 0.1', 'dataMax + 0.2']} tickCount={6} />
//                 <Tooltip />
//                 <Legend />
//                 <Line type="monotone" dataKey="파고" stroke="#0da" />
//               </LineChart>
//             </ResponsiveContainer>
            
//           </div>
//         </div >
//       )
//       }
//     </>
//   )
// }
